// M. Zubair Adnan i22-0789-B
#include <iostream>
using namespace std;
int main()
{
	int a,b, sum=0, mod=0, no_sticks=0;
	int arr[10]={6, 2, 5, 5, 4, 5, 6, 3, 7, 6};
	cout<<"Enter the two number you want to sum:\n";
	cin>>a>>b;
	sum = a+b;
	if( a == 0 || b==0)
	{
		if( a == 0 && b ==0)
		{ 
			no_sticks= arr[0] + arr[0];
		}
		else if ( a==0)
		{
		no_sticks= arr[0] + arr[b];
		}
		else
		{
		no_sticks= arr[0] + arr[a];
		}
		cout<<"The number of sticks required are: "<<no_sticks;
		return 0;
	}
	while( sum!=0 )
	{
		mod= sum%10;
		sum= sum/10;
		no_sticks= no_sticks + arr[mod];
	}

	cout<<"The number of sticks required are: "<<no_sticks;

return 0;
}

