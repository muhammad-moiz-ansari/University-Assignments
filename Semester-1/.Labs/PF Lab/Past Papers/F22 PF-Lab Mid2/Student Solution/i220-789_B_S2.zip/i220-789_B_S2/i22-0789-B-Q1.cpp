/* M.Zubair Adnan i22-0789-B */
#include <iostream>
#include <cmath>
using namespace std;
int func_f(int x, int k, int a1, int a2);
int func_g(int t, int k,  int a1, int a2);
int main()
{
	int a1, a2, t, k;
	int sum=0;
	cout<<"This program will print a series according to the defined functions.\n";
	cout<<"Enter the value of a1= ";
	cin>>a1;
	cout<<"Enter the value of a2= ";
	cin>>a2;
	cout<<"Enter the value of T: ";
	cin>>t;
	cout<<"Enter the value of K= ";
	cin>>k;
	for(int i=0; i<=k; ++i)
	{
		cout<<func_g(t, i, a1, a2)<<" ";
	}
return 0;
}
int func_f(int x, int k, int a1, int a2)
{
	int sum=0;
	sum = pow((x+a1),k) + pow((x+a2),k);
	return sum;
}
int func_g(int t, int k, int a1, int a2)
{
	int sum=0;
	for(int i=0; i<=t; ++i)
	{
		sum = sum + func_f(i, k, a1, a2);
	}
	return sum;
}
