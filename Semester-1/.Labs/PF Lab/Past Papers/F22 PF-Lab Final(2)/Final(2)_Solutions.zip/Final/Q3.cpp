#include <iostream>
using namespace std;
int * mostFrequnentElementsInArray(int *array, int size, int frequency){
    int *dup_freq=new int[size];
    int index=0;
    for (int i = 0; i < size; i++)
    {   int item_count=0;
        bool flag=true;
        for(int j=i; j<size; j++){
            if(array[i]==array[j])
                item_count++;
        }
        for(int j=0; j<index; j++){
            if(array[i]==dup_freq[j]){
                flag=false;
                break;
            }
        }
        if(item_count >= frequency && flag==true)
            dup_freq[index++]=array[i];
        
    }
    return dup_freq;

}

int main(){
    int Arr[]={2,2,4,2,4,5,6,1,1};
    int *res=mostFrequnentElementsInArray(Arr, 9, 2);
    for(int i=0; i<9; i++){
        cout<<res[i]<<endl;
    }



}