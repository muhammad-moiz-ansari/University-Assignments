#include <iostream>
using namespace std;
void  remove_word (char arr[], string remove_words [], int size=5){
    int prev=0;
    string new_sent="";
    for(int i=0; arr[i]; i++ ){
    //
    string word="";
    bool flag=true;
    if(arr[i]==' '){
        for(int j=prev; j<i; j++)
            word += arr[j];
        for(int var=0; var<size; var++){
            if(remove_words[var] == word){
                flag=false;
                break;
            }
        } 
        
    if(flag)
        new_sent += word+" ";
    prev=i+1;          
    }
      
}
    for(int i=0; new_sent[i]; i++)
        cout << new_sent[i];
    
}

void display_word_count(char words [] ){

// if somemone wrote the logic of wrod spliting then counting it wil be okk

}

int  *alphabets_count(char words [] ){
    int *alpha= new int[26];
    for(int i=0; words[i]; i++){
        if(words[i]>=97 && words[i]<=122){
            alpha[words[i]-'a']++;
        }
    }
    return alpha;
}
int main(){
    string remove_words[] = {"is", "am", "of", "are", "the"};
    // char corpus[]="hello i am toqeer how is the life? what is going in the life? life is very short.";
        char corpus[]="aabbccdd";
    remove_word(corpus, remove_words);

    int *alpha=alphabets_count(corpus);
    for(int i=0; i<26; i++){
        cout<<char(i+97)<<" : "<<alpha[i]<<endl;
    }
}