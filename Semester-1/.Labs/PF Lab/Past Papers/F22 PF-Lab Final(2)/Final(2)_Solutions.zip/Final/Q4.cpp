#include <iostream>
using namespace std;
int count(int n) {
  if (n < 0) {
    // base case: if n is negative, there are no solutions
    return 0;
  } else if (n == 0) {
    // base case: if n is zero, there is 1 solution (the empty sum)
    return 1;
  } else {
    // recursive case: the number of ways to write n as a sum of 1, 3, and 4
    // is the sum of the number of ways to write (n-1), (n-3), and (n-4)
    return count(n-1) + count(n-3) + count(n-4);
  }
}

int main() {
  int n = 5;
  int ways = count(n);
  cout << "There are " << ways << " ways to write " << n << " as the sum of 1, 3, and 4." << endl;
  return 0;
}
	

