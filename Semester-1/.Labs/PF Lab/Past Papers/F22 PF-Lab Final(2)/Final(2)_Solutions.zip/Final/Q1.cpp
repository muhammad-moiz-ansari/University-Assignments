#include <iostream>

using namespace std;


void applyFilter(int matrix[][6],int filter[][2]){
    int O=(6-2/2)+1;
    int mat2[O][O];
    int r=0, c=0;
    int mat_max;
    int filt_max=0;
    for (int i = 0; i < 2; i++)
    {
        for(int j=0; j<2; j++){
            if(filt_max<filter[i][j]){
                filt_max = filter[i][j];
            }
        }
    }

    for (int i = 0; i < 6; i+=2)
    {   c=0;
        for(int j=0; j<6; j+=2){
            mat_max=0;
             for (int k = i; k < i+2; k++)
            {
                
            for(int l=j; l<j+2; l++){
                if(mat_max<matrix[k][l]){
                    mat_max = matrix[k][l];
                }
                }
            }
           
            // cout<<mat_max<<" "<<filt_max<<endl;
            if(mat_max>filt_max) 
                mat2[r][c++]=mat_max;
            else
                mat2[r][c++]=filt_max;
        }
        r+=1;
        
    }
    
     for (int i = 0; i < 3; i++)
    {
        for(int j=0; j<3; j++){
            cout<<mat2[i][j]<<" ";
        }
        cout<<endl;
    }   

}


int main(){
    int mat[6][6]={
        {128,197,256,88,134,0},
        {31,176,256,76,14,60},
        {11, 145, 32, 89, 11, 7},
        {12,167,48,89,31,8},
        {51,18,255,67,13,60},
        {161,19,76,67,41,40}
    };

    int filter[2][2]={{33,45},{11,110}};
    applyFilter(mat,filter);
    return 0;
}
