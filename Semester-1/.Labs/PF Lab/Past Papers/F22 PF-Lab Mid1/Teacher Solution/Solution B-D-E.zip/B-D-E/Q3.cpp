#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main(){
	string name;
	cout << "Enter name: ";
	getline(cin, name);
	int gross;
	cout << "Enter amount: ";
	cin >> gross;
	float fit, st, sst, mt, pp, hi, pi;
	fit = gross - (gross * ((100 - 15) / 100.0));
	st = gross - (gross * ((100 - 3.5) / 100.0));
	sst = gross - (gross * ((100 - 5.75) / 100.0));
	pp = gross - (gross * ((100 - 5) / 100.0));
	hi = 75;	
	float netpay = gross - (fit + st + sst + pp + hi);
	cout << name << endl;
	cout << "Gross Amount:" << setw(12) << setfill('.') << fixed << setprecision(2) << gross << endl;
	cout << "Federal Tax:" << setw(12) << setfill('.') << fixed << setprecision(2) << fit << endl;
	cout << "State Tax:" << setw(12) << setfill('.') << fixed << setprecision(2) << st << endl;
	cout << "Social security Tax:" << setw(12) << setfill('.') << fixed << setprecision(2) << sst << endl;
	cout << "Pension Plan:" << setw(12) << setfill('.') << fixed << setprecision(2) << pp << endl;
	cout << "Health Insurance:" << setw(12) << setfill('.') << fixed << setprecision(2) << hi << endl;
	cout << "Netpay:" << setw(12) << setfill('.') << fixed << setprecision(2) << netpay << endl;
	
	return 0;
}
