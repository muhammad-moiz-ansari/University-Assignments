#include <iostream>
using namespace std;
int main()
{   
    int N=0;
    cout<<"Enter number"<<endl;
    cin>>N;
    //changing all right side bits to 1.
    N = N| (N>>1);
    N = N| (N>>2);
    N = N| (N>>4);
    N = N| (N>>8);
    cout<<"The largest power of 2 is: "<< ( ( N + 1 ) >> 1 )<<endl;
 
    return 0;
}

