#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	cout << "***********" << endl;
	cout << "*****" << setw(6) << "*****" << endl;
	cout << "****" << setw(7) << "****" << endl;
	cout << "***" << setw(8) << "***" << endl;
	cout << "**" << setw(9) << "**" << endl;
	cout << "*" << setw(10) << "*" << endl; 

	return 0;
}

