#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
int main()
{
	cout<<"Porgram to display shape using stew function:\n";
	cout<<setw(11)<<"***********\n";
	cout<<setw(5)<<"*****"<<setw(7)<<"*****\n";
	cout<<setw(4)<<"****"<<setw(8)<<"****\n";
	cout<<setw(3)<<"***"<<setw(9)<<"***\n";
	cout<<setw(2)<<"**"<<setw(10)<<"**\n";
	cout<<setw(1)<<"*"<<setw(11)<<"*\n";

return 0;
}
