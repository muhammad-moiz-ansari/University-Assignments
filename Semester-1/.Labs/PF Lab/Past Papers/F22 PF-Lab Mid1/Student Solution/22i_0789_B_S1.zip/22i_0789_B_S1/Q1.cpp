#include<iostream>
#include<string>
using namespace std;
int main() 
{
	int num1,num2,sum,diff,product;
	string name;	
	cout<<"Enter your name\t";
	cin>>name;

	cout<<"\nHello "<<name;   
	
	cout<<"\nEnter first Number : ";
    cin>>num1;      //ASUME THAT USER GIVES INPUT AS 5

    cout<<"\nEnter second Number : ";
    cin>>num2;     //ASUME THAT USER GIVES INPUT AS 5

    sum=num1+num2;

    cout<<"\nSum is"<<sum;

    diff=num1-num2;

    cout<<"\nOriginal difference is : "<<diff; //removed insertion ope between sum and string display

    num1+=2;      //ADDING 2 more to the num variable
    num2+=2;     //ADDING 2 more to the num2 variable

    product=num1*num2;

    cout<<"\nProduct of  two number is: "<<product;

    //cout<<"\nBy dividing we get out answer as"<<(num+num2)/diff;
	//This output is not stated in the original question
    diff=diff+10;  

	cout<<"\nUpdated diff is"<<diff; 

return 0;
}
