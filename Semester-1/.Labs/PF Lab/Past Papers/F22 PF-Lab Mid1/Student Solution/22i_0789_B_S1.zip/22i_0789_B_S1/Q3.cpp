#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main()
{
	string name;
	float GP1,GP2;
	float FT=15, ST=3.5, SS=5.75, MM=2.75, PP=5, HI=75; 
	cout<<"Enter the employees name: ";
	cin>>name;
	cout<<"\nEnter the employees gorss pay: ";
	cin>>GP1;
	FT= GP1*(FT/100);
	ST= GP1*(ST/100);
	SS= GP1*(SS/100);
	MM= GP1*(MM/100);
	PP= GP1*(PP/100);
//Divide the tax percentage by 100 to get the equivalent decimal value
	GP2= GP1-FT-ST-SS-MM-PP-HI;
	cout<<name<<endl;
	cout<<"\nGross amount: "<<GP1;
	cout<<"\nFederal Tax: "<<FT;
	cout<<"\nState Tax: "<<ST;
	cout<<"\nSocial Security Tax: "<<SS;
	cout<<"\nMedicare/Medicaid Tax: "<<MM;
	cout<<"\nPension Plan: "<<PP;
	cout<<"\nHealth Insurance is: "<<HI;
	cout<<setprecision(8)<<"\nNet Pay: "<<GP2;

return 0;
}


