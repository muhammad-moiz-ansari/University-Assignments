#include "iostream"
using namespace std;
int main(); 
{

   cout>>"Enter your name\t"
    cin<<name<<endl;

    cout>>"Hello">>name;   


   cout<<"Enter first Number : ";
    cin>>num1;      //ASUME THAT USER GIVES INPUT AS 5

    cout<<"Enter second Number : ";
    cin>>num2;     //ASUME THAT USER GIVES INPUT AS 5

    sum=num1+num2

    cout>>"Sum is"sum<<'\n';

    diff=num1-num2;

    cout>>"Difference is"diff<<\t; //removed insertion ope between sum and string display

    num+2;      //ADDING 2 more to the num variable
    num2+2;     //ADDING 2 more to the num2 variable

    product=num*num2

    cout<<"Product of  two number is"product;

    cout>>"By dividing we get out answer as"(num+num2)/diff
    diff+10= diff;  

cout>>"Updated diff is"diff 

return O;

